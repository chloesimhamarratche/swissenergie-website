import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { CheckCircle2 } from 'lucide-react';

function LeadForm() {
  const [formData, setFormData] = useState({
    ageLogement: '',
    chauffage: '',
    codePostal: '',
    surface: '',
    foyer: '',
    emetteur: '',
    nom: '',
    prenom: '',
    telephone: ''
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validatePhone = (phone) => {
    const phoneRegex = /^(06|01|04)[0-9]{8}$/;
    return phoneRegex.test(phone);
  };

  const validateCodePostal = (code) => {
    return /^[0-9]{5}$/.test(code);
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const newErrors = {};
    
    if (!formData.ageLogement) newErrors.ageLogement = 'Ce champ est requis';
    if (!formData.chauffage) newErrors.chauffage = 'Ce champ est requis';
    if (!formData.codePostal) {
      newErrors.codePostal = 'Ce champ est requis';
    } else if (!validateCodePostal(formData.codePostal)) {
      newErrors.codePostal = 'Code postal invalide (5 chiffres requis)';
    }
    if (!formData.surface) newErrors.surface = 'Ce champ est requis';
    if (!formData.foyer) newErrors.foyer = 'Ce champ est requis';
    if (!formData.emetteur) newErrors.emetteur = 'Ce champ est requis';
    if (!formData.nom) newErrors.nom = 'Ce champ est requis';
    if (!formData.prenom) newErrors.prenom = 'Ce champ est requis';
    if (!formData.telephone) {
      newErrors.telephone = 'Ce champ est requis';
    } else if (!validatePhone(formData.telephone)) {
      newErrors.telephone = 'Veuillez entrer un numéro valide.';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      const existingLeads = JSON.parse(localStorage.getItem('leads') || '[]');
      
      const newLead = {
        ...formData,
        timestamp: new Date().toISOString()
      };
      
      existingLeads.push(newLead);
      localStorage.setItem('leads', JSON.stringify(existingLeads));
      
      console.log('Lead saved:', newLead);
      console.log('All leads:', existingLeads);
      
      toast.success('Merci! Votre demande a été enregistrée.', {
        description: 'Nous vous contacterons très prochainement.',
        duration: 5000
      });
      
      setFormData({
        ageLogement: '',
        chauffage: '',
        codePostal: '',
        surface: '',
        foyer: '',
        emetteur: '',
        nom: '',
        prenom: '',
        telephone: ''
      });
      
      setErrors({});
    } catch (error) {
      console.error('Error saving lead:', error);
      toast.error('Une erreur est survenue. Veuillez réessayer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="ageLogement" className="text-sm font-medium">
          Âge du logement <span className="text-destructive">*</span>
        </Label>
        <Select value={formData.ageLogement} onValueChange={(value) => handleInputChange('ageLogement', value)}>
          <SelectTrigger id="ageLogement" className={errors.ageLogement ? 'border-destructive' : ''}>
            <SelectValue placeholder="Sélectionnez l'âge du logement" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="moins-2-ans">Moins de 2 ans</SelectItem>
            <SelectItem value="2-15-ans">Entre 2 et 15 ans</SelectItem>
            <SelectItem value="plus-15-ans">Plus de 15 ans</SelectItem>
          </SelectContent>
        </Select>
        {errors.ageLogement && <p className="text-sm text-destructive">{errors.ageLogement}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="chauffage" className="text-sm font-medium">
          Système de chauffage actuel <span className="text-destructive">*</span>
        </Label>
        <Select value={formData.chauffage} onValueChange={(value) => handleInputChange('chauffage', value)}>
          <SelectTrigger id="chauffage" className={errors.chauffage ? 'border-destructive' : ''}>
            <SelectValue placeholder="Sélectionnez votre système" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="gaz">Chaudière à gaz</SelectItem>
            <SelectItem value="fioul">Chaudière à fioul</SelectItem>
            <SelectItem value="pac">Pompe à chaleur</SelectItem>
            <SelectItem value="autre">Autre</SelectItem>
          </SelectContent>
        </Select>
        {errors.chauffage && <p className="text-sm text-destructive">{errors.chauffage}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="codePostal" className="text-sm font-medium">
          Code postal <span className="text-destructive">*</span>
        </Label>
        <Input
          id="codePostal"
          type="text"
          placeholder="75001"
          value={formData.codePostal}
          onChange={(e) => handleInputChange('codePostal', e.target.value)}
          maxLength={5}
          className={errors.codePostal ? 'border-destructive' : ''}
        />
        {errors.codePostal && <p className="text-sm text-destructive">{errors.codePostal}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="surface" className="text-sm font-medium">
          Surface de la maison en m² <span className="text-destructive">*</span>
        </Label>
        <Input
          id="surface"
          type="number"
          placeholder="120"
          value={formData.surface}
          onChange={(e) => handleInputChange('surface', e.target.value)}
          min="1"
          className={errors.surface ? 'border-destructive' : ''}
        />
        {errors.surface && <p className="text-sm text-destructive">{errors.surface}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="foyer" className="text-sm font-medium">
          Nombre de personnes dans le foyer <span className="text-destructive">*</span>
        </Label>
        <Input
          id="foyer"
          type="number"
          placeholder="4"
          value={formData.foyer}
          onChange={(e) => handleInputChange('foyer', e.target.value)}
          min="1"
          className={errors.foyer ? 'border-destructive' : ''}
        />
        {errors.foyer && <p className="text-sm text-destructive">{errors.foyer}</p>}
      </div>

      <div className="space-y-2">
        <Label htmlFor="emetteur" className="text-sm font-medium">
          Type d'émetteur <span className="text-destructive">*</span>
        </Label>
        <Select value={formData.emetteur} onValueChange={(value) => handleInputChange('emetteur', value)}>
          <SelectTrigger id="emetteur" className={errors.emetteur ? 'border-destructive' : ''}>
            <SelectValue placeholder="Sélectionnez le type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="radiateurs">Radiateurs</SelectItem>
            <SelectItem value="plancher">Plancher chauffant</SelectItem>
          </SelectContent>
        </Select>
        {errors.emetteur && <p className="text-sm text-destructive">{errors.emetteur}</p>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="nom" className="text-sm font-medium">
            Nom <span className="text-destructive">*</span>
          </Label>
          <Input
            id="nom"
            type="text"
            placeholder="Dupont"
            value={formData.nom}
            onChange={(e) => handleInputChange('nom', e.target.value)}
            className={errors.nom ? 'border-destructive' : ''}
          />
          {errors.nom && <p className="text-sm text-destructive">{errors.nom}</p>}
        </div>

        <div className="space-y-2">
          <Label htmlFor="prenom" className="text-sm font-medium">
            Prénom <span className="text-destructive">*</span>
          </Label>
          <Input
            id="prenom"
            type="text"
            placeholder="Marie"
            value={formData.prenom}
            onChange={(e) => handleInputChange('prenom', e.target.value)}
            className={errors.prenom ? 'border-destructive' : ''}
          />
          {errors.prenom && <p className="text-sm text-destructive">{errors.prenom}</p>}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="telephone" className="text-sm font-medium">
          Numéro de téléphone portable <span className="text-destructive">*</span>
        </Label>
        <Input
          id="telephone"
          type="tel"
          placeholder="0612345678"
          value={formData.telephone}
          onChange={(e) => handleInputChange('telephone', e.target.value)}
          maxLength={10}
          className={errors.telephone ? 'border-destructive' : ''}
        />
        {errors.telephone && <p className="text-sm text-destructive">{errors.telephone}</p>}
      </div>

      <Button
        type="submit"
        size="lg"
        className="w-full transition-all duration-200 hover:scale-[1.02] hover:shadow-lg active:scale-[0.98]"
        disabled={isSubmitting}
      >
        {isSubmitting ? (
          <span className="flex items-center gap-2">
            <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent"></span>
            Envoi en cours...
          </span>
        ) : (
          <span className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5" />
            Vérifier mon éligibilité
          </span>
        )}
      </Button>
    </form>
  );
}

export default LeadForm;