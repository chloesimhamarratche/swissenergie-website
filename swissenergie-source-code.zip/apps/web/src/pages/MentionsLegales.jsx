import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

function MentionsLegales() {
  return (
    <>
      <Helmet>
        <title>Mentions Légales - Swiss Energie</title>
        <meta name="description" content="Mentions légales du site Swiss Energie." />
      </Helmet>

      <div className="min-h-screen bg-background py-12 md:py-20">
        <div className="container max-w-3xl mx-auto px-4">
          <Link 
            to="/" 
            className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-8 transition-colors duration-200"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à l'accueil
          </Link>

          <h1 className="text-3xl md:text-4xl font-bold mb-10 tracking-tight">Mentions Légales</h1>

          <div className="space-y-10 text-muted-foreground">
            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">1. Éditeur du site</h2>
              <p>
                Le site <strong>Swiss Energie</strong> est édité par la société SWISSENERGIE, 
                société par actions simplifiée (SAS) au capital de 10 000 euros, dont le siège social est situé au :
              </p>
              <address className="not-italic pl-4 border-l-2 border-border">
                123 Avenue des Champs-Élysées<br />
                75008 Paris<br />
                France
              </address>
              <p>
                Immatriculée au Registre du Commerce et des Sociétés de Paris sous le numéro : 123 456 789 R.C.S. Paris.<br />
                Numéro de TVA intracommunautaire : FR 12 345678901
              </p>
              <p>
                <strong>Directeur de la publication :</strong> Jean Dupont, en qualité de Président.<br />
                <strong>Contact :</strong> contact@swiss-energie.fr | +33 (0)1 23 45 67 89
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">2. Hébergement</h2>
              <p>
                Ce site est hébergé par <strong>Hostinger International Ltd.</strong>
              </p>
              <address className="not-italic pl-4 border-l-2 border-border">
                61 Lordou Vironos Street<br />
                6023 Larnaca<br />
                Chypre
              </address>
              <p>
                Site web : <a href="https://www.hostinger.fr" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">www.hostinger.fr</a>
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">3. Propriété intellectuelle</h2>
              <p>
                L'ensemble de ce site relève de la législation française et internationale sur le droit d'auteur et la propriété intellectuelle. Tous les droits de reproduction sont réservés, y compris pour les documents téléchargeables et les représentations iconographiques et photographiques.
              </p>
              <p>
                La reproduction de tout ou partie de ce site sur un support électronique quel qu'il soit est formellement interdite sauf autorisation expresse du directeur de la publication.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">4. Responsabilité</h2>
              <p>
                L'éditeur s'efforce d'assurer au mieux de ses possibilités, l'exactitude et la mise à jour des informations diffusées sur ce site, dont il se réserve le droit de corriger, à tout moment et sans préavis, le contenu.
              </p>
              <p>
                Toutefois, l'éditeur ne peut garantir l'exactitude, la précision ou l'exhaustivité des informations mises à la disposition sur ce site. En conséquence, l'éditeur décline toute responsabilité pour toute imprécision, inexactitude ou omission portant sur des informations disponibles sur le site.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">5. Données personnelles</h2>
              <p>
                D'une façon générale, vous pouvez visiter notre site sur Internet sans avoir à décliner votre identité et à fournir des informations personnelles vous concernant. Cependant, nous pouvons parfois vous demander des informations, par exemple, pour traiter une demande de contact ou établir un devis.
              </p>
              <p>
                Conformément à la loi « informatique et libertés » du 6 janvier 1978 modifiée et au Règlement Européen sur la Protection des Données (RGPD), vous bénéficiez d'un droit d'accès, de rectification, de portabilité et d'effacement de vos données ou encore de limitation du traitement. Vous pouvez également, pour des motifs légitimes, vous opposer au traitement des données vous concernant.
              </p>
              <p>
                Pour exercer ces droits, vous pouvez nous contacter à l'adresse email suivante : dpo@swiss-energie.fr.
              </p>
            </section>
          </div>
        </div>
      </div>
    </>
  );
}

export default MentionsLegales;