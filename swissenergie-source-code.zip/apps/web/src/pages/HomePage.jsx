import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import LeadForm from '@/components/LeadForm.jsx';

function HomePage() {
  const scrollToForm = () => {
    const formSection = document.getElementById('form-section');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <Helmet>
        <title>Swiss Energie - Accueil</title>
        <meta name="description" content="Vérifiez votre éligibilité gratuitement en moins de 30 secondes pour obtenir jusqu'à 9 000€ d'aides pour votre pompe à chaleur." />
      </Helmet>

      <Toaster />

      <div className="min-h-screen">
        <section className="relative flex items-center justify-center min-h-[100dvh] overflow-hidden">
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1700124108954-49db9cfe3e22)' }}
          >
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/70"></div>
          </div>

          <div className="absolute top-0 left-0 right-0 p-6 lg:p-8 z-10">
            <div className="container max-w-7xl mx-auto">
              <div className="flex items-center gap-2">
                <span className="text-2xl font-bold text-white tracking-tight">
                  <span className="text-primary">Swiss</span> Energie
                </span>
              </div>
            </div>
          </div>

          <div className="relative z-10 container max-w-4xl mx-auto px-4 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-white mb-6 leading-tight" style={{ letterSpacing: '-0.02em' }}>
                Jusqu'à 9 000€ d'aides pour votre pompe à chaleur
              </h1>
              <p className="text-xl md:text-2xl text-white/90 mb-12 mx-auto leading-relaxed">
                Vérifiez votre éligibilité gratuitement en moins de 30 secondes
              </p>
              <motion.button
                onClick={scrollToForm}
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-8 py-4 rounded-xl text-lg font-semibold transition-all duration-200 hover:bg-primary/90 hover:scale-105 hover:shadow-xl active:scale-[0.98]"
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                Commencer maintenant
                <ChevronDown className="h-5 w-5 animate-bounce" />
              </motion.button>
            </motion.div>
          </div>

          <motion.div
            className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <button
              onClick={scrollToForm}
              className="text-white/80 hover:text-white transition-colors duration-200"
              aria-label="Scroll to form"
            >
              <ChevronDown className="h-8 w-8" />
            </button>
          </motion.div>
        </section>

        <section id="form-section" className="py-20 bg-secondary">
          <div className="container max-w-2xl mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="text-center mb-12">
                <h2 className="mb-4">Vérifiez votre éligibilité</h2>
                <p className="text-lg text-muted-foreground">
                  Remplissez le formulaire ci-dessous pour découvrir le montant des aides auxquelles vous avez droit
                </p>
              </div>

              <div className="bg-card rounded-2xl shadow-lg p-8 md:p-10">
                <LeadForm />
              </div>

              <div className="mt-8 text-center text-sm text-muted-foreground">
                <p>Vos données sont sécurisées et ne seront jamais partagées avec des tiers</p>
              </div>
            </motion.div>
          </div>
        </section>

        <footer className="bg-card border-t py-8">
          <div className="container max-w-7xl mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight">
                  <span className="text-primary">Swiss</span> Energie
                </span>
              </div>
              
              <div className="flex items-center gap-6 text-sm text-muted-foreground">
                <span>© 2024 Swiss Energie - Tous droits réservés</span>
                <Link to="/mentions-legales" className="hover:text-foreground transition-colors duration-200">Mentions légales</Link>
                <Link to="/politique-confidentialite" className="hover:text-foreground transition-colors duration-200">Politique de confidentialité</Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}

export default HomePage;