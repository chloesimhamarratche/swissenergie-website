import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

function PolitiqueConfidentialite() {
  return (
    <>
      <Helmet>
        <title>Politique de Confidentialité - Swiss Energie</title>
        <meta name="description" content="Politique de confidentialité et protection des données personnelles de Swiss Energie." />
      </Helmet>

      <div className="min-h-screen bg-background py-12 md:py-20">
        <div className="container max-w-3xl mx-auto px-4">
          <Link 
            to="/" 
            className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-8 transition-colors duration-200"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à l'accueil
          </Link>

          <h1 className="text-3xl md:text-4xl font-bold mb-10 tracking-tight">Politique de Confidentialité</h1>

          <div className="space-y-10 text-muted-foreground leading-relaxed">
            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">1. Introduction</h2>
              <p>
                Chez <strong>Swiss Energie</strong>, nous accordons une importance primordiale à la protection de vos données personnelles. Cette politique de confidentialité vise à vous informer de manière transparente sur la façon dont nous collectons, utilisons, partageons et protégeons vos données lorsque vous utilisez notre site web et nos services.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">2. Responsable du traitement</h2>
              <p>
                Le responsable du traitement des données personnelles collectées sur ce site est la société SWISSENERGIE, dont les coordonnées complètes figurent à la fin de ce document (Section 10).
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">3. Données collectées</h2>
              <p>
                Dans le cadre de l'utilisation de nos services, notamment lors de la vérification de votre éligibilité aux aides pour les pompes à chaleur, nous pouvons être amenés à collecter les données suivantes :
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Données d'identification :</strong> nom, prénom.</li>
                <li><strong>Données de contact :</strong> adresse e-mail, numéro de téléphone, adresse postale.</li>
                <li><strong>Données relatives à votre projet :</strong> type de logement, système de chauffage actuel, revenus du foyer (pour estimer les aides).</li>
                <li><strong>Données de navigation :</strong> adresse IP, cookies, pages consultées.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">4. Finalités du traitement</h2>
              <p>
                Vos données personnelles sont collectées et traitées pour les finalités suivantes :
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li>Évaluer votre éligibilité aux aides gouvernementales pour la transition énergétique.</li>
                <li>Vous recontacter pour vous proposer un accompagnement personnalisé et un devis.</li>
                <li>Améliorer l'expérience utilisateur sur notre site web.</li>
                <li>Répondre à nos obligations légales et réglementaires.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">5. Base légale du traitement</h2>
              <p>
                Conformément au RGPD, le traitement de vos données repose sur les bases légales suivantes :
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Votre consentement :</strong> lorsque vous soumettez volontairement le formulaire d'éligibilité.</li>
                <li><strong>L'exécution de mesures précontractuelles :</strong> pour vous fournir un devis ou une estimation.</li>
                <li><strong>Notre intérêt légitime :</strong> pour l'amélioration continue de nos services.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">6. Destinataires des données</h2>
              <p>
                Vos données personnelles sont destinées exclusivement aux équipes internes de Swiss Energie. Elles ne sont en aucun cas vendues, louées ou cédées à des tiers à des fins commerciales. Nous pouvons toutefois partager vos données avec des prestataires techniques (hébergeur, outil CRM) agissant en notre nom et sous nos instructions, dans le strict respect de la sécurité de vos données.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">7. Durée de conservation</h2>
              <p>
                Nous conservons vos données personnelles uniquement le temps nécessaire à l'accomplissement des finalités pour lesquelles elles ont été collectées :
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Données des prospects :</strong> 3 ans à compter du dernier contact émanant de votre part.</li>
                <li><strong>Données des clients :</strong> pendant toute la durée de la relation commerciale, puis archivées selon les délais de prescription légale (généralement 5 à 10 ans).</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">8. Vos droits (Conformité RGPD)</h2>
              <p>
                Conformément à la réglementation européenne (RGPD) et à la loi Informatique et Libertés, vous disposez des droits suivants concernant vos données personnelles :
              </p>
              <ul className="list-disc pl-6 space-y-2">
                <li><strong>Droit d'accès :</strong> obtenir la confirmation que vos données sont traitées et en obtenir une copie.</li>
                <li><strong>Droit de rectification :</strong> demander la correction de données inexactes ou incomplètes.</li>
                <li><strong>Droit à l'effacement (droit à l'oubli) :</strong> demander la suppression de vos données dans certaines conditions.</li>
                <li><strong>Droit à la limitation du traitement :</strong> geler temporairement l'utilisation de vos données.</li>
                <li><strong>Droit à la portabilité :</strong> recevoir vos données dans un format structuré pour les transmettre à un autre responsable.</li>
                <li><strong>Droit d'opposition :</strong> vous opposer au traitement de vos données pour des raisons tenant à votre situation particulière, ou à des fins de prospection commerciale.</li>
                <li><strong>Droit de retirer votre consentement :</strong> à tout moment, lorsque le traitement est fondé sur celui-ci.</li>
                <li><strong>Droit d'introduire une réclamation :</strong> auprès de la CNIL (Commission Nationale de l'Informatique et des Libertés) si vous estimez que vos droits ne sont pas respectés.</li>
              </ul>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">9. Sécurité des données</h2>
              <p>
                Nous mettons en œuvre des mesures techniques et organisationnelles appropriées pour protéger vos données personnelles contre la destruction accidentelle ou illicite, la perte, l'altération, la divulgation ou l'accès non autorisé. Notre site utilise notamment le protocole HTTPS pour garantir le chiffrement des données lors de leur transmission.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-xl font-semibold text-foreground">10. Contact</h2>
              <p>
                Pour toute question relative à cette politique de confidentialité ou pour exercer vos droits, vous pouvez nous contacter aux coordonnées suivantes :
              </p>
              <address className="not-italic pl-4 border-l-2 border-border mt-4 space-y-1">
                <strong>SWISSENERGIE</strong><br />
                97 Rue Sauveur Tobelem<br />
                13007 Marseille — France<br />
                Email : <a href="mailto:contact@swissenerg.com" className="text-primary hover:underline">contact@swissenerg.com</a>
              </address>
            </section>
          </div>

          <div className="mt-16 pt-8 border-t border-border text-center">
            <Link 
              to="/" 
              className="inline-flex items-center text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour à la page d'accueil
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}

export default PolitiqueConfidentialite;